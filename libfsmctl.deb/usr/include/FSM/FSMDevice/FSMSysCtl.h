#ifndef FSMSysCtl
#define FSMSysCtl
void FSM_SendCtlCmd(struct FSM_SendCmdUserspace* fsmdat);
#endif