#ifndef FSM_E1_CAS
#define FSM_E1_CAS

struct FSME1CAS
{
    char reg;
    int idstream;
    int idcon;
};


#endif